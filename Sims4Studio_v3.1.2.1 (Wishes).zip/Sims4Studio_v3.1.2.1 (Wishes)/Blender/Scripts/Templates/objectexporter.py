import io,bpy
from io_sims import find_armature
from s4studio.blender import set_context
from s4studio.buybuild.blender import save_lod, load_lod
from s4studio.buybuild.geometry import ModelLod

mlod_file = u'__MLOD__'

geometry_state = u'__STATE__'
state_hash = None if geometry_state == u'' else int(geometry_state)
mlod = ModelLod()
with io.open(mlod_file, 'rb') as mlod_stream:
    mlod.read(mlod_stream)
    save_lod(mlod,geometry_state)
set_context('OBJECT',None)
with io.open(mlod_file.replace('.mlod','.out.mlod'), 'wb') as mlod_stream:
    mlod.write(mlod_stream)
rig=find_armature(bpy.context)
bpy.ops.wm.quit_blender()