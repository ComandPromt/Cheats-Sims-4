import bpy,os
bpy.context.user_preferences.filepaths.script_directory ='%s\\Blender Foundation\\\Blender\\__VERSION__\\\scripts'% os.getenv('APPDATA')
bpy.ops.wm.save_userpref()