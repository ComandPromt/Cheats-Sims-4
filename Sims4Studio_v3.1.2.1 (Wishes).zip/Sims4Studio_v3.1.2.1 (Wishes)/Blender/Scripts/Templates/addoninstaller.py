import bpy
bpy.ops.wm.addon_disable(module='io_sims')
bpy.ops.wm.addon_enable(module='io_sims')      
bpy.ops.wm.save_userpref()