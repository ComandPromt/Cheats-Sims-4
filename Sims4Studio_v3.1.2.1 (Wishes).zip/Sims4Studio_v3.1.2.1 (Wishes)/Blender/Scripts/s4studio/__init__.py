__author__ = 'Sims4Group'


bl_info = {
    'name': 'Sims 4 Studio Blender Library',
    'version': (1, 0,0),
    'blender': (2, 70, 0),
    'category': 'Import-Export',
    'location': 'File > Import/Export'
}